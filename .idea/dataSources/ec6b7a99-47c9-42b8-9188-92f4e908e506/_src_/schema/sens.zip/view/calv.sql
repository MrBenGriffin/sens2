CREATE VIEW calv AS
  SELECT
    `c`.`id`                                        AS `cal`,
    concat(`h`.`name`, `t`.`name`, ' ', `y`.`name`) AS `name`,
    concat(`y`.`id`, '.', `t`.`id`, `h`.`id`)       AS `sort`
  FROM (((`sens`.`calendar` `c`
    JOIN `sens`.`year` `y`) JOIN `sens`.`term` `t`) JOIN `sens`.`halft` `h`)
  WHERE ((`y`.`id` = `c`.`year`) AND (`t`.`id` = `c`.`term`) AND (`h`.`id` = `c`.`halft`))
  ORDER BY concat(`y`.`id`, '.', `t`.`id`, `h`.`id`);
