CREATE VIEW classv AS
  SELECT
    `c`.`id`     AS `class`,
    `c`.`school` AS `school`,
    `v`.`cohort` AS `cohort`,
    `u`.`user`   AS `teacher`,
    `c`.`active` AS `active`,
    `c`.`name`   AS `name`,
    `v`.`name`   AS `cname`,
    `v`.`xname`  AS `cxname`,
    `v`.`sort`   AS `sort`,
    `u`.`name`   AS `tname`
  FROM ((`sens`.`class` `c`
    JOIN `sens`.`cohv` `v`) JOIN `sens`.`userv` `u`)
  WHERE ((`c`.`school` = `u`.`school`) AND (`v`.`school` = `c`.`school`) AND (`u`.`user` = `c`.`teacher`) AND
         (`c`.`cohort` = `v`.`cohort`));
