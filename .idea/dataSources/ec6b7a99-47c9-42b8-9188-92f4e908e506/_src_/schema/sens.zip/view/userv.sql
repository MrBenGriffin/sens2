CREATE VIEW userv AS
  SELECT
    `u`.`id`                                       AS `user`,
    `p`.`school`                                   AS `school`,
    concat(`p`.`firstname`, ' ', `p`.`familyname`) AS `name`,
    `p`.`role`                                     AS `role`,
    `r`.`name`                                     AS `rname`
  FROM ((`sens`.`sio_user` `u`
    JOIN `sens`.`sio_role` `r`) JOIN `sens`.`sio_userprofile` `p`)
  WHERE ((`u`.`id` = `p`.`user`) AND (`p`.`role` = `r`.`id`));
