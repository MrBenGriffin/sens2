CREATE VIEW cohv AS
  SELECT
    `c`.`id`                                                       AS `cohort`,
    `c`.`school`                                                   AS `school`,
    concat(`y`.`name`, ' ', `g`.`name`)                            AS `name`,
    concat(`y`.`name`, ' ', `g`.`name`, ' (', `c`.`comments`, ')') AS `xname`,
    concat(`y`.`id`, '.', `g`.`id`)                                AS `sort`
  FROM ((`sens`.`cohort` `c`
    JOIN `sens`.`year` `y`) JOIN `sens`.`gang` `g`)
  WHERE ((`y`.`id` = `c`.`year`) AND (`g`.`id` = `c`.`gang`));
